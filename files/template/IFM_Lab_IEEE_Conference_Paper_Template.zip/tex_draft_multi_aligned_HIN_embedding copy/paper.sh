rm main.log
rm main.bbl
rm main.aux
rm main.pdf

pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex

rm main.log
rm main.aux
rm main.blg
rm main.synctex.gz
open main.pdf
