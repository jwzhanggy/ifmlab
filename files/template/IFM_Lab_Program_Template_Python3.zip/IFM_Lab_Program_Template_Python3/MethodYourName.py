'''
Concrete MethodModule class for a specific learning MethodModule
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD

from method import method


class MethodYourName(method):
    alpha = 0.0
    data = None
    
    def train(self, training_set):
        pass
    
    def test(self, testing_set):
        pass
    
    def run(self):
        #---- get training set from data ----
        training_set = {}
        testing_set = {}
        self.train(training_set)
        return self.test(testing_set)
            