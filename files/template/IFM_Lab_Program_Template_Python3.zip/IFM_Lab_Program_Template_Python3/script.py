from DatasetLocal import DatasetLocal
from MethodSVM import MethodSVM
from MethodDT import MethodDT
from ResultSaving import ResultSaving
from SettingCV import SettingCV
from EvaluateAcc import EvaluateAcc

#---- SVM baseline method ----
if 1:
    #---- parameter section -------------------------------
    c = 1.0
    #------------------------------------------------------
    
    #---- objection initialization setction ---------------
    data_obj = DatasetLocal('', '')
    data_obj.dataset_source_folder_path = './data_samples/'
    data_obj.dataset_source_file_name = 'test_data_file.txt'
    
    method_obj = MethodSVM('', '')
    method_obj.c = c
    
    result_obj = ResultSaving('', '')
    result_obj.result_destination_folder_path = './result_samples/SVM_'
    result_obj.result_destination_file_name = 'prediction_result_' + str(c)
    
    setting_obj = SettingCV('', '')
    
    evaluate_obj = EvaluateAcc('', '')
    #------------------------------------------------------
    
    #---- running section ---------------------------------
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    mean_score, std_score = setting_obj.load_run_save_evaluate()
    print('SVM Accuracy: ' + str(mean_score) + ' +/- ' + str(std_score))
    #------------------------------------------------------
    

#---- Decision Tree baseline method ----
if 1:
    #---- parameter section -------------------------------
    None
    #------------------------------------------------------
    
    #---- objection initialization setction ---------------
    data_obj = DatasetLocal('', '')
    data_obj.dataset_source_folder_path = './data_samples/'
    data_obj.dataset_source_file_name = 'test_data_file.txt'
    
    method_obj = MethodDT('', '')
    
    result_obj = ResultSaving('', '')
    result_obj.result_destination_folder_path = './result_samples/DT_'
    result_obj.result_destination_file_name = 'prediction_result'
    
    setting_obj = SettingCV('', '')
    
    evaluate_obj = EvaluateAcc('', '')
    #------------------------------------------------------
    
    #---- running section ---------------------------------
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    mean_score, std_score = setting_obj.load_run_save_evaluate()
    print('Decision Tree Accuracy: ' + str(mean_score) + ' +/- ' + str(std_score))
    #------------------------------------------------------
    
    
    
    