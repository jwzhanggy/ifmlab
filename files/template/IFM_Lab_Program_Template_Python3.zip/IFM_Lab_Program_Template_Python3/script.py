from DatasetYourName import DatasetYourName
from MethodYourName import MethodYourName
from ResultYourName import ResultYourName
from SettingYourName import SettingYourName
from EvaluateYourName import EvaluateYourName


if 1:
    #---- parameter section -------------------------------
    alpha = 1.0
    #------------------------------------------------------
    
    #---- objection initialization setction ---------------
    data_obj = DatasetYourName()
    data_obj.dataset_source_folder_path = './data_samples/'
    data_obj.dataset_source_file_name = 'test_data_file.txt'
    
    method_obj = MethodYourName()
    method_obj.alpha = alpha
    
    result_obj = ResultYourName()
    result_obj.result_destination_folder_path = './result_samples/'
    result_obj.result_destination_file_name = 'prediction_result_' + str(alpha)
    
    setting_obj = SettingYourName()
    
    evaluate_obj = EvaluateYourName()
    #------------------------------------------------------
    
    #---- running section ---------------------------------
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    setting_obj.load_run_save_evaluate()
    #------------------------------------------------------
    