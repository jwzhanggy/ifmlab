'''
Concrete MethodModule class for a specific learning MethodModule
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD

from method import method
from sklearn import svm


class MethodSVM(method):
    c = None
    data = None
    
    def train(self, X, y):
        model = svm.SVC(C = self.c)
        model.fit(X, y)
        return model
    
    def test(self, model, X):
        return model.predict(X)
    
    def run(self):
        model = self.train(self.data['train']['X'], self.data['train']['y'])
        pred_y = self.test(model, self.data['test']['X'])
        return {'pred_y': pred_y, 'true_y': self.data['test']['y']}
            