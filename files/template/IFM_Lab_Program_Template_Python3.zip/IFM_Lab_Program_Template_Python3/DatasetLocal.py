'''
Concrete IO class for a specific dataset
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD

from dataset import dataset


class DatasetLocal(dataset):
    data = None
    
    dataset_source_folder_path = None
    dataset_source_file_name = None
    
    def __init__(self, dName=None, dDescription=None):
        super().__init__(dName, dDescription)
    
    def load(self):
        X = []
        y = []
        f = open(self.dataset_source_folder_path + self.dataset_source_file_name)
        for line in f:
            line = line.strip('\n')
            elements = [int(i) for i in line.split(' ')]
            X.append(elements[:-1])
            y.append(elements[-1])
        return {'X': X, 'y': y}