main="enterprise_community_detection"
rm $main.lop
rm $main.bbl
rm $main.aux
rm $main.pdf
pdflatex $main.tex
bibtex $main
pdflatex $main.tex
open $main.pdf
