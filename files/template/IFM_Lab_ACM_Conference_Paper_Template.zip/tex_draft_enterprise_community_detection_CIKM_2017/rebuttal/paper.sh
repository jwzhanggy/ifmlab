rm main.lop
rm main.bbl
rm main.aux
rm main.pdf
make
