'''
Concrete result class for a specific experiment result output
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD

from result import result
import pickle


class ResultTest(result):
    data = None
    
    result_destination_folder_path = None
    result_destination_file_name = None
    
    def save(self):
        f = open(self.result_destination_folder_path + self.result_destination_file_name, 'w')
        pickle.dump(self.data, f)
        f.close()