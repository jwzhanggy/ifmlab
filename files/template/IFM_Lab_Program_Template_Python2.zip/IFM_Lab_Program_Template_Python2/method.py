'''
Base method class for all models and frameworks
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD


import abc


class method:
    '''
    method: Abstract Class
    Entries: method_name: the name of the method 
             method_description: the textual description of the method
             
             method_start_time: start running time of method
             method_stop_time: stop running time of method
             method_running_time: total running time of the method
             method_training_time: time cost of the training phrase
             method_testing_time: time cost of the testing phrase
    '''
    
    method_name = None
    method_description = None
    
    data = None
    
    method_start_time = None
    method_stop_time = None
    method_running_time = None
    method_training_time = None
    method_testing_time = None

    # initialization function
    def __init__(self, mName, mDescription):
        self.methodName = mName
        self.method_description = mDescription

    # running function
    @abc.abstractmethod
    def run(self, trainData, trainLabel, testData):
        return
