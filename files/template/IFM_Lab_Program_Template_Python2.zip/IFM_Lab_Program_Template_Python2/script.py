from DatasetTest import DatasetTest
from MethodTest import MethodTest
from ResultTest import ResultTest
from SettingTest import SettingTest
from EvaluateTest import EvaluateTest


if 1:
    #---- parameter section -------------------------------
    alpha = 5.0
    #------------------------------------------------------
    
    #---- objection initialization setction ---------------
    data_obj = DatasetTest('', '')
    data_obj.dataset_source_folder_path = './data_samples/'
    data_obj.dataset_source_file_name = 'test_data_file.txt'
    
    method_obj = MethodTest('', '')
    method_obj.alpha = alpha
    
    result_obj = ResultTest('', '')
    result_obj.result_destination_folder_path = './result_samples/'
    result_obj.result_destination_file_name = 'prediction_result_' + str(alpha)
    
    setting_obj = SettingTest('', '')
    
    evaluate_obj = EvaluateTest('', '')
    #------------------------------------------------------
    
    #---- running section ---------------------------------
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    evaluation_result = setting_obj.load_run_save_evaluate()
    print evaluation_result
    #------------------------------------------------------
    