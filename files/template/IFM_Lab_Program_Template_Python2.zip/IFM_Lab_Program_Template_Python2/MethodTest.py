'''
Concrete method class for a specific learning method
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD

from method import method


class MethodTest(method):
    alpha = 0.0
    data = None
    
    def train(self, training_set):
        pass
    
    def testing(self, model, testing_set):
        pred_y = []
        true_y = []
        for x, y in zip(testing_set['X'], testing_set['y']):
            pred_y.append(x[0] <= self.alpha and 1 or 0)
            true_y.append(y)
        return {'pred_y': pred_y, 'true_y': true_y}
    
    def run(self):
        model = self.train(self.data['train'])
        return self.testing(model, self.data['test'])
            